from project.worker import Worker


class Vet(Worker):
    pass
