from project.mammal import Mammal


class Bear(Mammal):
    pass
